﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_venta
{
    public partial class Provee : Form
    {
        public Provee()
        {
            InitializeComponent();
        }

        private void proveedorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.proveedorBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.baseDeDatosPapeleriaSofDataSet);

        }

        private void Provee_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.Provee' Puede moverla o quitarla según sea necesario.
            this.proveeTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.Provee);
            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.Producto' Puede moverla o quitarla según sea necesario.
            this.productoTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.Producto);
            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.Proveedor' Puede moverla o quitarla según sea necesario.
            this.proveedorTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.Proveedor);

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            var seleccion = MessageBox.Show("¿Deseas salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (seleccion == DialogResult.Yes)
            {
                this.Hide();
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string claveProveedor = proveedorComboBox.SelectedValue.ToString();
            string claveProducto = productoComboBox.SelectedValue.ToString();

            baseDatos bd = new baseDatos();
            Boolean res = bd.agregarProvee(claveProveedor, claveProducto);

            if (res)
            {
                MessageBox.Show("Relacion agregada correctamente","Relacion agregada", MessageBoxButtons.OK);
                Provee_Load(sender, e);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            string claveProveedor = proveedorComboBox.SelectedValue.ToString();
            string claveProducto = productoComboBox.SelectedValue.ToString();

            baseDatos bd = new baseDatos();
            Boolean res = bd.eliminarProvee(claveProveedor, claveProducto);

            if (res)
            {
                MessageBox.Show("Relacion eliminada correctamente", "Relacion eliminada", MessageBoxButtons.OK);
                Provee_Load(sender, e);
            }
        }
    }
}
