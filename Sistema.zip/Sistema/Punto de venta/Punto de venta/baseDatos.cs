﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace Punto_de_venta
{
    class baseDatos
    {
        private string cadenaConexion = "Data Source=JOSEPC; Initial Catalog=BaseDeDatosPapeleriaSof; Integrated Security=true;";

        public static string nombreIS = "";
        public static string adminIS = "";
        public static string claveIS = "";

        public Boolean iniciarSesion(string id, string password)
        {
            nombreIS = "";
            adminIS = "";
            claveIS = "";

            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();

            SqlParameter parID = new SqlParameter("@id", id);
            SqlParameter parPASSWORD = new SqlParameter("@password", password);

            SqlCommand comando = new SqlCommand("SELECT nombreEmpleado, empleadoAdmin, claveEmpleado FROM Empleado WHERE claveEmpleado = @id and passwordEmpleado COLLATE Latin1_General_CS_AS = @password", conexion);
            comando.Parameters.Add(parID);
            comando.Parameters.Add(parPASSWORD);

            SqlDataReader lector = comando.ExecuteReader();
            while (lector.Read())
            {
                nombreIS = lector.GetString(0);
                adminIS = lector.GetString(1);
                claveIS = lector.GetString(2);
            }

            lector.Close();
            conexion.Close();

            if (string.IsNullOrEmpty(adminIS))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public Boolean registrarTienda(string nombreTienda, string nombreDueno, string RFCTienda, string direccionTienda)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "UPDATE Tienda SET nombreTienda = '"+nombreTienda+"', duenoTienda = '"+nombreDueno+"', RFCTienda = '"+RFCTienda+"', direccionTienda = '"+direccionTienda+"' WHERE claveTienda = '1';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();

            return true;
        }

        public Boolean agregarEmpleado(string clave, string nombre, string telefono, string admin, string password)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "INSERT INTO Empleado VALUES('"+clave+"','"+nombre+"','"+telefono+"','"+admin+"','"+password+"')";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();

            return true;
        }

        public Boolean eliminarEmpleado(string clave)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();

            string comandoSQL2 = "DELETE FROM Venta WHERE claveEmpleadoV = '" + clave + "';";
            SqlCommand comando2 = new SqlCommand(comandoSQL2, conexion);
            comando2.ExecuteNonQuery();

            string comandoSQL = "DELETE FROM Empleado WHERE claveEmpleado = '" + clave + "';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();

            conexion.Close();

            return true;

        }

        public Boolean modificarEmpleado(string clave, string nombre, string telefono, string admin, string password)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "UPDATE Empleado SET nombreEmpleado = '"+nombre+"', telefonoEmpleado = '"+telefono+"', empleadoAdmin = '"+admin+"', passwordEmpleado = '"+password+"' WHERE claveEmpleado = '"+clave+"';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();

            return true;
        }

        public Boolean agregarProducto(string clave, string nombre, float precio, string marca, string des)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "INSERT INTO Producto VALUES ('"+clave+"' ,'"+nombre+"' ,'"+precio+"' ,'"+marca+"' ,'"+des+"');";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();

            return true;
        }

        public Boolean eliminarProducto(string clave)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();

            string comandoSQL2 = "DELETE FROM Provee WHERE claveProductoP = '" + clave + "';";
            SqlCommand comando2 = new SqlCommand(comandoSQL2, conexion);
            comando2.ExecuteNonQuery();

            string comandoSQL3 = "DELETE FROM DetallesVenta WHERE claveProductoDV = '" + clave + "';";
            SqlCommand comando3 = new SqlCommand(comandoSQL3, conexion);
            comando3.ExecuteNonQuery();

            string comandoSQL = "DELETE FROM Producto WHERE claveProducto = '" + clave + "';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();

            return true;
        }

        public Boolean modificarProducto(string clave, string nombre, float precio, string marca, string des)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "UPDATE Producto SET nombreProducto = '" + nombre + "', precioProducto = '" + precio + "', marcaProducto = '" + marca + "', descripcionProducto = '" + des + "' WHERE claveProducto = '" + clave + "';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();

            return true;
        }

        public Boolean agregarProveedor(string clave, string nombre, string correo, string telefono,  string direccion)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "INSERT INTO Proveedor VALUES ('"+clave+"','"+nombre+ "','" + correo + "','" + telefono+"','"+direccion+"');";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();

            return true;
        }

        public Boolean eliminarProveedor(string clave)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();

            string comandoSQL = "DELETE FROM Provee WHERE claveProveedorP = '" + clave + "';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();

            string comandoSQL2 = "DELETE FROM Proveedor WHERE claveProveedor = '" + clave + "';";
            SqlCommand comando2 = new SqlCommand(comandoSQL2, conexion);
            comando2.ExecuteNonQuery();

            conexion.Close();

            return true;
        }

        public Boolean modificarProveedor(string clave, string nombre, string correo, string telefono, string direccion)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "UPDATE Proveedor SET nombreProveedor = '" + nombre + "', correoProveedor = '"+correo+"', telefonoProveedor = '"+telefono+"', direccionProveedor = '"+direccion+"' WHERE claveProveedor = '"+clave+"';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();

            return true;
        }

        public Boolean agregarProvee(string claveProveedor, string claveProducto)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "INSERT INTO Provee VALUES ('"+claveProveedor+"','"+claveProducto+"');";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();

            return true;
        }

        public Boolean eliminarProvee(string claveProveedor, string claveProducto)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "DELETE FROM Provee WHERE claveProveedorP = '"+claveProveedor+"' AND claveProductoP = '"+claveProducto+"'; ";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();

            return true;
        }

        public int saberCantidadVentas()
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "SELECT COUNT(*) FROM Venta;";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            int  cantidadDeVentas = 0;

            SqlDataReader lector = comando.ExecuteReader();
            while(lector.Read())
            {
                cantidadDeVentas = lector.GetInt32(0);
            }

            lector.Close();
            conexion.Close();


            return cantidadDeVentas;
        }

        public void crearVentaVacia(string numeroVenta, string fecha)
        {
            string claveEmpleado = claveIS;
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "INSERT INTO Venta VALUES('"+numeroVenta+"', '"+claveEmpleado+"', '0', '"+fecha+"', '1');";
            SqlCommand comando = new SqlCommand( comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();
        }

        public void agregarAlCarrito(string numeroVenta, string claveProducto, string nombreProducto, Double cantidad, Double precio,Double subTotal)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "INSERT INTO DetallesVenta VALUES('"+numeroVenta+"','"+claveProducto+"','"+nombreProducto+"','"+cantidad+"','"+precio+"','"+subTotal+"');";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();
        }

        public string saberNombreProducto(string clave)
        {
            string nombreProducto = "";

            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "SELECT nombreProducto FROM Producto WHERE claveProducto = '" + clave + "';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);

            SqlDataReader lector = comando.ExecuteReader();
            while (lector.Read())
            {
                nombreProducto = lector.GetString(0);
            }
            lector.Close();
            conexion.Close();


            return (nombreProducto);
        }

        public Double saberPrecioProducto(string clave)
        {
            Double precioProducto = 0;

            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "SELECT precioProducto FROM Producto WHERE claveProducto = '" + clave + "';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);

            SqlDataReader lector = comando.ExecuteReader();
            while (lector.Read())
            {
                precioProducto = lector.GetDouble(0);
            }
            lector.Close();
            conexion.Close();

            return (precioProducto);
        }

        public void agregarVenta(double totalVenta, string numeroVenta)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "UPDATE Venta SET totalVentaV = '"+totalVenta+"' WHERE numeroVenta = '"+numeroVenta+"';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();
        }

        public void eliminarDetallesVenta(string clave)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "DELETE FROM DetallesVenta WHERE numeroVentaDV = '"+clave+"';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();
        }

        public void eliminarVenta(string clave)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "DELETE FROM Venta WHERE numeroVenta = '" + clave + "';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();
        }

        public DataTable tablaDV(string claveVenta)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "SELECT claveProductoDV, nombreProductoDV, cantidadDV, precio, subtotalDV FROM DetallesVenta WHERE numeroVentaDV = '"+claveVenta+"';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            SqlDataAdapter data = new SqlDataAdapter(comando);
            DataTable tabla = new DataTable();
            data.Fill(tabla);

            return tabla;
        }

        public void limpiarCochineroQueHayEnElRadio()
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            conexion.Open();
            string comandoSQL = "DELETE FROM Venta WHERE totalVentaV = '0';";
            SqlCommand comando = new SqlCommand(comandoSQL, conexion);
            comando.ExecuteNonQuery();
            conexion.Close();
        }
    }
}

