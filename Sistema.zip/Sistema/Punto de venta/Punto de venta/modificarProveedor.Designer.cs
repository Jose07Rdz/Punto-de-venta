﻿namespace Punto_de_venta
{
    partial class modificarProveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label claveProveedorLabel;
            System.Windows.Forms.Label nombreProveedorLabel;
            System.Windows.Forms.Label correoProveedorLabel;
            System.Windows.Forms.Label telefonoProveedorLabel;
            System.Windows.Forms.Label direccionProveedorLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(modificarProveedor));
            this.baseDeDatosPapeleriaSofDataSet = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSet();
            this.proveedorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.proveedorTableAdapter = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.ProveedorTableAdapter();
            this.tableAdapterManager = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager();
            this.proveedorDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.claveProveedorTextBox = new System.Windows.Forms.TextBox();
            this.nombreProveedorTextBox = new System.Windows.Forms.TextBox();
            this.correoProveedorTextBox = new System.Windows.Forms.TextBox();
            this.telefonoProveedorTextBox = new System.Windows.Forms.TextBox();
            this.direccionProveedorTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            claveProveedorLabel = new System.Windows.Forms.Label();
            nombreProveedorLabel = new System.Windows.Forms.Label();
            correoProveedorLabel = new System.Windows.Forms.Label();
            telefonoProveedorLabel = new System.Windows.Forms.Label();
            direccionProveedorLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.baseDeDatosPapeleriaSofDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.proveedorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.proveedorDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // claveProveedorLabel
            // 
            claveProveedorLabel.AutoSize = true;
            claveProveedorLabel.Location = new System.Drawing.Point(89, 90);
            claveProveedorLabel.Name = "claveProveedorLabel";
            claveProveedorLabel.Size = new System.Drawing.Size(41, 13);
            claveProveedorLabel.TabIndex = 46;
            claveProveedorLabel.Text = "*Clave:";
            // 
            // nombreProveedorLabel
            // 
            nombreProveedorLabel.AutoSize = true;
            nombreProveedorLabel.Location = new System.Drawing.Point(83, 163);
            nombreProveedorLabel.Name = "nombreProveedorLabel";
            nombreProveedorLabel.Size = new System.Drawing.Size(47, 13);
            nombreProveedorLabel.TabIndex = 48;
            nombreProveedorLabel.Text = "Nombre:";
            // 
            // correoProveedorLabel
            // 
            correoProveedorLabel.AutoSize = true;
            correoProveedorLabel.Location = new System.Drawing.Point(89, 189);
            correoProveedorLabel.Name = "correoProveedorLabel";
            correoProveedorLabel.Size = new System.Drawing.Size(41, 13);
            correoProveedorLabel.TabIndex = 50;
            correoProveedorLabel.Text = "Correo:";
            // 
            // telefonoProveedorLabel
            // 
            telefonoProveedorLabel.AutoSize = true;
            telefonoProveedorLabel.Location = new System.Drawing.Point(78, 215);
            telefonoProveedorLabel.Name = "telefonoProveedorLabel";
            telefonoProveedorLabel.Size = new System.Drawing.Size(52, 13);
            telefonoProveedorLabel.TabIndex = 52;
            telefonoProveedorLabel.Text = "Telefono:";
            // 
            // direccionProveedorLabel
            // 
            direccionProveedorLabel.AutoSize = true;
            direccionProveedorLabel.Location = new System.Drawing.Point(75, 241);
            direccionProveedorLabel.Name = "direccionProveedorLabel";
            direccionProveedorLabel.Size = new System.Drawing.Size(55, 13);
            direccionProveedorLabel.TabIndex = 54;
            direccionProveedorLabel.Text = "Direccion:";
            // 
            // baseDeDatosPapeleriaSofDataSet
            // 
            this.baseDeDatosPapeleriaSofDataSet.DataSetName = "BaseDeDatosPapeleriaSofDataSet";
            this.baseDeDatosPapeleriaSofDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // proveedorBindingSource
            // 
            this.proveedorBindingSource.DataMember = "Proveedor";
            this.proveedorBindingSource.DataSource = this.baseDeDatosPapeleriaSofDataSet;
            // 
            // proveedorTableAdapter
            // 
            this.proveedorTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DetallesVentaTableAdapter = null;
            this.tableAdapterManager.EmpleadoTableAdapter = null;
            this.tableAdapterManager.ProductoTableAdapter = null;
            this.tableAdapterManager.ProveedorTableAdapter = this.proveedorTableAdapter;
            this.tableAdapterManager.ProveeTableAdapter = null;
            this.tableAdapterManager.TiendaTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VentaTableAdapter = null;
            // 
            // proveedorDataGridView
            // 
            this.proveedorDataGridView.AutoGenerateColumns = false;
            this.proveedorDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.proveedorDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.proveedorDataGridView.DataSource = this.proveedorBindingSource;
            this.proveedorDataGridView.Location = new System.Drawing.Point(299, 78);
            this.proveedorDataGridView.Name = "proveedorDataGridView";
            this.proveedorDataGridView.Size = new System.Drawing.Size(545, 251);
            this.proveedorDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "claveProveedor";
            this.dataGridViewTextBoxColumn1.HeaderText = "claveProveedor";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "nombreProveedor";
            this.dataGridViewTextBoxColumn2.HeaderText = "nombreProveedor";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "correoProveedor";
            this.dataGridViewTextBoxColumn3.HeaderText = "correoProveedor";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "telefonoProveedor";
            this.dataGridViewTextBoxColumn4.HeaderText = "telefonoProveedor";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "direccionProveedor";
            this.dataGridViewTextBoxColumn5.HeaderText = "direccionProveedor";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(472, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 18);
            this.label1.TabIndex = 28;
            this.label1.Text = "Lista de proveedor";
            // 
            // btnRegresar
            // 
            this.btnRegresar.Location = new System.Drawing.Point(797, 426);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(75, 23);
            this.btnRegresar.TabIndex = 44;
            this.btnRegresar.Text = "Regresar";
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.Location = new System.Drawing.Point(106, 306);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(75, 23);
            this.btnModificar.TabIndex = 45;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = true;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(55, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 18);
            this.label2.TabIndex = 46;
            this.label2.Text = "Modificar Proveedor";
            // 
            // claveProveedorTextBox
            // 
            this.claveProveedorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.proveedorBindingSource, "claveProveedor", true));
            this.claveProveedorTextBox.Location = new System.Drawing.Point(136, 87);
            this.claveProveedorTextBox.MaxLength = 5;
            this.claveProveedorTextBox.Name = "claveProveedorTextBox";
            this.claveProveedorTextBox.Size = new System.Drawing.Size(129, 20);
            this.claveProveedorTextBox.TabIndex = 47;
            // 
            // nombreProveedorTextBox
            // 
            this.nombreProveedorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.proveedorBindingSource, "nombreProveedor", true));
            this.nombreProveedorTextBox.Location = new System.Drawing.Point(136, 160);
            this.nombreProveedorTextBox.MaxLength = 50;
            this.nombreProveedorTextBox.Name = "nombreProveedorTextBox";
            this.nombreProveedorTextBox.Size = new System.Drawing.Size(129, 20);
            this.nombreProveedorTextBox.TabIndex = 49;
            // 
            // correoProveedorTextBox
            // 
            this.correoProveedorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.proveedorBindingSource, "correoProveedor", true));
            this.correoProveedorTextBox.Location = new System.Drawing.Point(136, 186);
            this.correoProveedorTextBox.MaxLength = 50;
            this.correoProveedorTextBox.Name = "correoProveedorTextBox";
            this.correoProveedorTextBox.Size = new System.Drawing.Size(129, 20);
            this.correoProveedorTextBox.TabIndex = 51;
            // 
            // telefonoProveedorTextBox
            // 
            this.telefonoProveedorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.proveedorBindingSource, "telefonoProveedor", true));
            this.telefonoProveedorTextBox.Location = new System.Drawing.Point(136, 212);
            this.telefonoProveedorTextBox.MaxLength = 10;
            this.telefonoProveedorTextBox.Name = "telefonoProveedorTextBox";
            this.telefonoProveedorTextBox.Size = new System.Drawing.Size(129, 20);
            this.telefonoProveedorTextBox.TabIndex = 53;
            // 
            // direccionProveedorTextBox
            // 
            this.direccionProveedorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.proveedorBindingSource, "direccionProveedor", true));
            this.direccionProveedorTextBox.Location = new System.Drawing.Point(136, 238);
            this.direccionProveedorTextBox.MaxLength = 50;
            this.direccionProveedorTextBox.Name = "direccionProveedorTextBox";
            this.direccionProveedorTextBox.Size = new System.Drawing.Size(129, 20);
            this.direccionProveedorTextBox.TabIndex = 55;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 13);
            this.label3.TabIndex = 56;
            this.label3.Text = "* La clave no se puede cambiar";
            // 
            // modificarProveedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(892, 469);
            this.Controls.Add(this.label3);
            this.Controls.Add(claveProveedorLabel);
            this.Controls.Add(this.claveProveedorTextBox);
            this.Controls.Add(nombreProveedorLabel);
            this.Controls.Add(this.nombreProveedorTextBox);
            this.Controls.Add(correoProveedorLabel);
            this.Controls.Add(this.correoProveedorTextBox);
            this.Controls.Add(telefonoProveedorLabel);
            this.Controls.Add(this.telefonoProveedorTextBox);
            this.Controls.Add(direccionProveedorLabel);
            this.Controls.Add(this.direccionProveedorTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnModificar);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.proveedorDataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "modificarProveedor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Modificar Proveedor";
            this.Load += new System.EventHandler(this.modificarProveedor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.baseDeDatosPapeleriaSofDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.proveedorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.proveedorDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BaseDeDatosPapeleriaSofDataSet baseDeDatosPapeleriaSofDataSet;
        private System.Windows.Forms.BindingSource proveedorBindingSource;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.ProveedorTableAdapter proveedorTableAdapter;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView proveedorDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRegresar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox claveProveedorTextBox;
        private System.Windows.Forms.TextBox nombreProveedorTextBox;
        private System.Windows.Forms.TextBox correoProveedorTextBox;
        private System.Windows.Forms.TextBox telefonoProveedorTextBox;
        private System.Windows.Forms.TextBox direccionProveedorTextBox;
        private System.Windows.Forms.Label label3;
    }
}