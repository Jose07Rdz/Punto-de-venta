﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_venta
{
    public partial class eliminarEmpleado : Form
    {
        public eliminarEmpleado()
        {
            InitializeComponent();
        }

        private void empleadoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.empleadoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.baseDeDatosPapeleriaSofDataSet);

        }

        private void eliminarEmpleado_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.Empleado' Puede moverla o quitarla según sea necesario.
            this.empleadoTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.Empleado);

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            var seleccion = MessageBox.Show("¿Deseas salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (seleccion == DialogResult.Yes)
            {
                this.Hide();
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtBoxClave.Text))
            {
                baseDatos bd = new baseDatos();

                Boolean res = bd.eliminarEmpleado(txtBoxClave.Text);

                if(res)
                {
                    MessageBox.Show("El empleado con clave " + txtBoxClave.Text + " se ha eliminado correctamente", "Empleado eliminado", MessageBoxButtons.OK);
                    eliminarEmpleado_Load(sender, e);
                    txtBoxClave.Text = "";
                }
                else
                {
                    MessageBox.Show("No se ha podido eliminar el empleado", "Error", MessageBoxButtons.OK);
                }
            }
            else
            {
                MessageBox.Show("Complete los campos solicitados", "Datos faltantes", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
