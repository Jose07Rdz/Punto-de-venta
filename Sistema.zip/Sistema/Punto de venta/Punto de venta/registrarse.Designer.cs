﻿namespace Punto_de_venta
{
    partial class registrarse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(registrarse));
            this.label6 = new System.Windows.Forms.Label();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.btnRegistrarse = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBoxDir = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBoxRFC = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBoxNomDue = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBoxNomPape = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(424, 290);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "* Campos obligatorios";
            // 
            // btnRegresar
            // 
            this.btnRegresar.Location = new System.Drawing.Point(797, 426);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(75, 23);
            this.btnRegresar.TabIndex = 22;
            this.btnRegresar.Text = "Regresar";
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // btnRegistrarse
            // 
            this.btnRegistrarse.Location = new System.Drawing.Point(404, 330);
            this.btnRegistrarse.Name = "btnRegistrarse";
            this.btnRegistrarse.Size = new System.Drawing.Size(75, 23);
            this.btnRegistrarse.TabIndex = 21;
            this.btnRegistrarse.Text = "Registrarse";
            this.btnRegistrarse.UseVisualStyleBackColor = true;
            this.btnRegistrarse.Click += new System.EventHandler(this.btnRegistrarse_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Cursor = System.Windows.Forms.Cursors.Default;
            this.label5.Font = new System.Drawing.Font("Arial", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label5.Location = new System.Drawing.Point(365, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 31);
            this.label5.TabIndex = 20;
            this.label5.Text = "Registrarse";
            // 
            // txtBoxDir
            // 
            this.txtBoxDir.Location = new System.Drawing.Point(432, 256);
            this.txtBoxDir.MaxLength = 50;
            this.txtBoxDir.Name = "txtBoxDir";
            this.txtBoxDir.Size = new System.Drawing.Size(100, 20);
            this.txtBoxDir.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(299, 259);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "*Direccion de la papeleria:";
            // 
            // txtBoxRFC
            // 
            this.txtBoxRFC.Location = new System.Drawing.Point(432, 207);
            this.txtBoxRFC.MaxLength = 13;
            this.txtBoxRFC.Name = "txtBoxRFC";
            this.txtBoxRFC.Size = new System.Drawing.Size(100, 20);
            this.txtBoxRFC.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(391, 210);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "*RFC:";
            // 
            // txtBoxNomDue
            // 
            this.txtBoxNomDue.Location = new System.Drawing.Point(432, 158);
            this.txtBoxNomDue.MaxLength = 50;
            this.txtBoxNomDue.Name = "txtBoxNomDue";
            this.txtBoxNomDue.Size = new System.Drawing.Size(100, 20);
            this.txtBoxNomDue.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(325, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "*Nombre del dueño:";
            // 
            // txtBoxNomPape
            // 
            this.txtBoxNomPape.Location = new System.Drawing.Point(432, 108);
            this.txtBoxNomPape.MaxLength = 50;
            this.txtBoxNomPape.Name = "txtBoxNomPape";
            this.txtBoxNomPape.Size = new System.Drawing.Size(100, 20);
            this.txtBoxNomPape.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(307, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "*Nombre de la papeleria:";
            // 
            // registrarse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 461);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.btnRegistrarse);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtBoxDir);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtBoxRFC);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtBoxNomDue);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtBoxNomPape);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "registrarse";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registrarse";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnRegresar;
        private System.Windows.Forms.Button btnRegistrarse;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBoxDir;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBoxRFC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBoxNomDue;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBoxNomPape;
        private System.Windows.Forms.Label label1;
    }
}