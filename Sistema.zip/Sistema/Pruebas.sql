USE BaseDeDatosPapeleriaSof

SELECT * FROM DetallesVenta
SELECT * FROM Venta
SELECT * FROM Empleado
SELECT * FROM Producto
SELECT * FROM Proveedor
SELECT * FROM Provee	
SELECT * FROM Tienda


delete from DetallesVenta
delete from Venta