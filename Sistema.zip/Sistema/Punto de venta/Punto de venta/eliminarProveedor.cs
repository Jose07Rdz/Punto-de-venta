﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_venta
{
    public partial class eliminarProveedor : Form
    {
        public eliminarProveedor()
        {
            InitializeComponent();
        }

        private void proveedorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.proveedorBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.baseDeDatosPapeleriaSofDataSet);

        }

        private void eliminarProveedor_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.Proveedor' Puede moverla o quitarla según sea necesario.
            this.proveedorTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.Proveedor);
            txtBoxClave.Text = "";
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            var seleccion = MessageBox.Show("¿Deseas salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (seleccion == DialogResult.Yes)
            {
                this.Hide();
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(txtBoxClave.Text))
            {
                baseDatos bd = new baseDatos();

                Boolean res = bd.eliminarProveedor(txtBoxClave.Text);

                if (res)
                {
                    MessageBox.Show("El producto con clave " + txtBoxClave.Text + " se ha eliminado correctamente", "Producto eliminado", MessageBoxButtons.OK);
                    eliminarProveedor_Load(sender, e);
                }
                else
                {
                    MessageBox.Show("No se ha podido eliminar el proveedor", "Error", MessageBoxButtons.OK);
                }
            }
            else
            {
                MessageBox.Show("Complete los campos solicitados", "Datos faltantes", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
