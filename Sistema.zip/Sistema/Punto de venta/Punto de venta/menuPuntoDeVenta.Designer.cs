﻿namespace Punto_de_venta
{
    partial class menuPuntoDeVenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(menuPuntoDeVenta));
            this.baseDeDatosPapeleriaSofDataSet = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSet();
            this.ventaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ventaTableAdapter = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.VentaTableAdapter();
            this.tableAdapterManager = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnProvee = new System.Windows.Forms.Button();
            this.btnModProveedor = new System.Windows.Forms.Button();
            this.btnEliminarProveedor = new System.Windows.Forms.Button();
            this.btnModificarProveedor = new System.Windows.Forms.Button();
            this.btnEliminarProducto = new System.Windows.Forms.Button();
            this.btnModificarProducto = new System.Windows.Forms.Button();
            this.btnAgregarProducto = new System.Windows.Forms.Button();
            this.btnModificarEmpleado = new System.Windows.Forms.Button();
            this.btnEliminarEmpleados = new System.Windows.Forms.Button();
            this.btnAgregarEmpleado = new System.Windows.Forms.Button();
            this.btnCancelarVenta = new System.Windows.Forms.Button();
            this.btnRealizarVenta = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.baseDeDatosPapeleriaSofDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ventaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // baseDeDatosPapeleriaSofDataSet
            // 
            this.baseDeDatosPapeleriaSofDataSet.DataSetName = "BaseDeDatosPapeleriaSofDataSet";
            this.baseDeDatosPapeleriaSofDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ventaBindingSource
            // 
            this.ventaBindingSource.DataMember = "Venta";
            this.ventaBindingSource.DataSource = this.baseDeDatosPapeleriaSofDataSet;
            // 
            // ventaTableAdapter
            // 
            this.ventaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DetallesVentaTableAdapter = null;
            this.tableAdapterManager.EmpleadoTableAdapter = null;
            this.tableAdapterManager.ProductoTableAdapter = null;
            this.tableAdapterManager.ProveedorTableAdapter = null;
            this.tableAdapterManager.ProveeTableAdapter = null;
            this.tableAdapterManager.TiendaTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VentaTableAdapter = this.ventaTableAdapter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(276, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(333, 40);
            this.label1.TabIndex = 12;
            this.label1.Text = "MENU PRINCIPAL ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 18);
            this.label2.TabIndex = 13;
            this.label2.Text = "Ventas";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 18);
            this.label3.TabIndex = 14;
            this.label3.Text = "Empleados";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(9, 194);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 18);
            this.label4.TabIndex = 15;
            this.label4.Text = "Productos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 270);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 18);
            this.label5.TabIndex = 16;
            this.label5.Text = "Proveedor";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 346);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 18);
            this.label6.TabIndex = 17;
            this.label6.Text = "Provee";
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(797, 426);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(75, 23);
            this.btnSalir.TabIndex = 18;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnProvee
            // 
            this.btnProvee.Image = global::Punto_de_venta.Properties.Resources.proveedorProvee;
            this.btnProvee.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnProvee.Location = new System.Drawing.Point(12, 367);
            this.btnProvee.Name = "btnProvee";
            this.btnProvee.Size = new System.Drawing.Size(130, 45);
            this.btnProvee.TabIndex = 11;
            this.btnProvee.Text = "Proveedor Provee";
            this.btnProvee.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProvee.UseVisualStyleBackColor = true;
            this.btnProvee.Click += new System.EventHandler(this.btnProvee_Click);
            // 
            // btnModProveedor
            // 
            this.btnModProveedor.Image = global::Punto_de_venta.Properties.Resources.modificarProveedor;
            this.btnModProveedor.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModProveedor.Location = new System.Drawing.Point(314, 291);
            this.btnModProveedor.Name = "btnModProveedor";
            this.btnModProveedor.Size = new System.Drawing.Size(145, 45);
            this.btnModProveedor.TabIndex = 10;
            this.btnModProveedor.Text = "Modificar Proveedor";
            this.btnModProveedor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModProveedor.UseVisualStyleBackColor = true;
            this.btnModProveedor.Click += new System.EventHandler(this.btnModProveedor_Click);
            // 
            // btnEliminarProveedor
            // 
            this.btnEliminarProveedor.Image = global::Punto_de_venta.Properties.Resources.eliminarProveedor;
            this.btnEliminarProveedor.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEliminarProveedor.Location = new System.Drawing.Point(163, 291);
            this.btnEliminarProveedor.Name = "btnEliminarProveedor";
            this.btnEliminarProveedor.Size = new System.Drawing.Size(145, 45);
            this.btnEliminarProveedor.TabIndex = 9;
            this.btnEliminarProveedor.Text = "Eliminar Proveedor";
            this.btnEliminarProveedor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEliminarProveedor.UseVisualStyleBackColor = true;
            this.btnEliminarProveedor.Click += new System.EventHandler(this.btnEliminarProveedor_Click);
            // 
            // btnModificarProveedor
            // 
            this.btnModificarProveedor.Image = global::Punto_de_venta.Properties.Resources.agregarProveedor;
            this.btnModificarProveedor.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificarProveedor.Location = new System.Drawing.Point(12, 291);
            this.btnModificarProveedor.Name = "btnModificarProveedor";
            this.btnModificarProveedor.Size = new System.Drawing.Size(145, 45);
            this.btnModificarProveedor.TabIndex = 8;
            this.btnModificarProveedor.Text = "Agregar Proveedor";
            this.btnModificarProveedor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificarProveedor.UseVisualStyleBackColor = true;
            this.btnModificarProveedor.Click += new System.EventHandler(this.btnModificarProveedor_Click);
            // 
            // btnEliminarProducto
            // 
            this.btnEliminarProducto.Image = global::Punto_de_venta.Properties.Resources.eliminarProducto;
            this.btnEliminarProducto.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEliminarProducto.Location = new System.Drawing.Point(148, 215);
            this.btnEliminarProducto.Name = "btnEliminarProducto";
            this.btnEliminarProducto.Size = new System.Drawing.Size(130, 45);
            this.btnEliminarProducto.TabIndex = 7;
            this.btnEliminarProducto.Text = "Eliminar Producto";
            this.btnEliminarProducto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEliminarProducto.UseVisualStyleBackColor = true;
            this.btnEliminarProducto.Click += new System.EventHandler(this.btnEliminarProducto_Click);
            // 
            // btnModificarProducto
            // 
            this.btnModificarProducto.Image = global::Punto_de_venta.Properties.Resources.modificarProducto4;
            this.btnModificarProducto.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificarProducto.Location = new System.Drawing.Point(284, 215);
            this.btnModificarProducto.Name = "btnModificarProducto";
            this.btnModificarProducto.Size = new System.Drawing.Size(130, 45);
            this.btnModificarProducto.TabIndex = 6;
            this.btnModificarProducto.Text = "Modificar Producto";
            this.btnModificarProducto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificarProducto.UseVisualStyleBackColor = true;
            this.btnModificarProducto.Click += new System.EventHandler(this.btnModificarProducto_Click);
            // 
            // btnAgregarProducto
            // 
            this.btnAgregarProducto.Image = global::Punto_de_venta.Properties.Resources.agregarProducto;
            this.btnAgregarProducto.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregarProducto.Location = new System.Drawing.Point(12, 215);
            this.btnAgregarProducto.Name = "btnAgregarProducto";
            this.btnAgregarProducto.Size = new System.Drawing.Size(130, 45);
            this.btnAgregarProducto.TabIndex = 5;
            this.btnAgregarProducto.Text = "Agregar Producto";
            this.btnAgregarProducto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgregarProducto.UseVisualStyleBackColor = true;
            this.btnAgregarProducto.Click += new System.EventHandler(this.btnAgregarProducto_Click);
            // 
            // btnModificarEmpleado
            // 
            this.btnModificarEmpleado.Image = global::Punto_de_venta.Properties.Resources.monoLapis;
            this.btnModificarEmpleado.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificarEmpleado.Location = new System.Drawing.Point(284, 139);
            this.btnModificarEmpleado.Name = "btnModificarEmpleado";
            this.btnModificarEmpleado.Size = new System.Drawing.Size(130, 45);
            this.btnModificarEmpleado.TabIndex = 4;
            this.btnModificarEmpleado.Text = "Modificar Empleado";
            this.btnModificarEmpleado.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificarEmpleado.UseVisualStyleBackColor = true;
            this.btnModificarEmpleado.Click += new System.EventHandler(this.btnModificarEmpleado_Click);
            // 
            // btnEliminarEmpleados
            // 
            this.btnEliminarEmpleados.Image = global::Punto_de_venta.Properties.Resources.monoEquiz;
            this.btnEliminarEmpleados.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEliminarEmpleados.Location = new System.Drawing.Point(148, 139);
            this.btnEliminarEmpleados.Name = "btnEliminarEmpleados";
            this.btnEliminarEmpleados.Size = new System.Drawing.Size(130, 45);
            this.btnEliminarEmpleados.TabIndex = 3;
            this.btnEliminarEmpleados.Text = "Eliminar Empleado";
            this.btnEliminarEmpleados.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEliminarEmpleados.UseVisualStyleBackColor = true;
            this.btnEliminarEmpleados.Click += new System.EventHandler(this.btnEliminarEmpleados_Click);
            // 
            // btnAgregarEmpleado
            // 
            this.btnAgregarEmpleado.Image = global::Punto_de_venta.Properties.Resources.monoMas;
            this.btnAgregarEmpleado.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregarEmpleado.Location = new System.Drawing.Point(12, 139);
            this.btnAgregarEmpleado.Name = "btnAgregarEmpleado";
            this.btnAgregarEmpleado.Size = new System.Drawing.Size(130, 45);
            this.btnAgregarEmpleado.TabIndex = 2;
            this.btnAgregarEmpleado.Text = "Agregar Empleado";
            this.btnAgregarEmpleado.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgregarEmpleado.UseVisualStyleBackColor = true;
            this.btnAgregarEmpleado.Click += new System.EventHandler(this.btnAgregarEmpleado_Click);
            // 
            // btnCancelarVenta
            // 
            this.btnCancelarVenta.Image = global::Punto_de_venta.Properties.Resources.cancelarVenta1;
            this.btnCancelarVenta.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelarVenta.Location = new System.Drawing.Point(148, 62);
            this.btnCancelarVenta.Name = "btnCancelarVenta";
            this.btnCancelarVenta.Size = new System.Drawing.Size(130, 45);
            this.btnCancelarVenta.TabIndex = 1;
            this.btnCancelarVenta.Text = "Cancelar venta";
            this.btnCancelarVenta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarVenta.UseVisualStyleBackColor = true;
            this.btnCancelarVenta.Click += new System.EventHandler(this.btnCancelarVenta_Click);
            // 
            // btnRealizarVenta
            // 
            this.btnRealizarVenta.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRealizarVenta.Image = global::Punto_de_venta.Properties.Resources.realizarVenta1;
            this.btnRealizarVenta.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRealizarVenta.Location = new System.Drawing.Point(12, 62);
            this.btnRealizarVenta.Name = "btnRealizarVenta";
            this.btnRealizarVenta.Size = new System.Drawing.Size(130, 45);
            this.btnRealizarVenta.TabIndex = 0;
            this.btnRealizarVenta.Text = "Realizar venta";
            this.btnRealizarVenta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRealizarVenta.UseVisualStyleBackColor = false;
            this.btnRealizarVenta.Click += new System.EventHandler(this.btnRealizarVenta_Click);
            // 
            // menuPuntoDeVenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.ClientSize = new System.Drawing.Size(884, 461);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnProvee);
            this.Controls.Add(this.btnModProveedor);
            this.Controls.Add(this.btnEliminarProveedor);
            this.Controls.Add(this.btnModificarProveedor);
            this.Controls.Add(this.btnEliminarProducto);
            this.Controls.Add(this.btnModificarProducto);
            this.Controls.Add(this.btnAgregarProducto);
            this.Controls.Add(this.btnModificarEmpleado);
            this.Controls.Add(this.btnEliminarEmpleados);
            this.Controls.Add(this.btnAgregarEmpleado);
            this.Controls.Add(this.btnCancelarVenta);
            this.Controls.Add(this.btnRealizarVenta);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "menuPuntoDeVenta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Punto de venta";
            ((System.ComponentModel.ISupportInitialize)(this.baseDeDatosPapeleriaSofDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ventaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private BaseDeDatosPapeleriaSofDataSet baseDeDatosPapeleriaSofDataSet;
        private System.Windows.Forms.BindingSource ventaBindingSource;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.VentaTableAdapter ventaTableAdapter;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button btnRealizarVenta;
        private System.Windows.Forms.Button btnCancelarVenta;
        private System.Windows.Forms.Button btnAgregarEmpleado;
        private System.Windows.Forms.Button btnAgregarProducto;
        private System.Windows.Forms.Button btnModificarProveedor;
        private System.Windows.Forms.Button btnProvee;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnModProveedor;
        private System.Windows.Forms.Button btnEliminarProveedor;
        private System.Windows.Forms.Button btnModificarProducto;
        private System.Windows.Forms.Button btnEliminarProducto;
        private System.Windows.Forms.Button btnModificarEmpleado;
        private System.Windows.Forms.Button btnEliminarEmpleados;
    }
}