﻿namespace Punto_de_venta
{
    partial class cancelarVenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label numeroVentaLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cancelarVenta));
            this.btnRegresar = new System.Windows.Forms.Button();
            this.baseDeDatosPapeleriaSofDataSet = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSet();
            this.ventaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ventaTableAdapter = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.VentaTableAdapter();
            this.tableAdapterManager = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager();
            this.ventaDataGridView = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.numeroVentaTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaVentaV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            numeroVentaLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.baseDeDatosPapeleriaSofDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ventaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ventaDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRegresar
            // 
            this.btnRegresar.Location = new System.Drawing.Point(797, 426);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(75, 23);
            this.btnRegresar.TabIndex = 46;
            this.btnRegresar.Text = "Regresar";
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // baseDeDatosPapeleriaSofDataSet
            // 
            this.baseDeDatosPapeleriaSofDataSet.DataSetName = "BaseDeDatosPapeleriaSofDataSet";
            this.baseDeDatosPapeleriaSofDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ventaBindingSource
            // 
            this.ventaBindingSource.DataMember = "Venta";
            this.ventaBindingSource.DataSource = this.baseDeDatosPapeleriaSofDataSet;
            // 
            // ventaTableAdapter
            // 
            this.ventaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DetallesVentaTableAdapter = null;
            this.tableAdapterManager.EmpleadoTableAdapter = null;
            this.tableAdapterManager.ProductoTableAdapter = null;
            this.tableAdapterManager.ProveedorTableAdapter = null;
            this.tableAdapterManager.ProveeTableAdapter = null;
            this.tableAdapterManager.TiendaTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VentaTableAdapter = this.ventaTableAdapter;
            // 
            // ventaDataGridView
            // 
            this.ventaDataGridView.AutoGenerateColumns = false;
            this.ventaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ventaDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.fechaVentaV});
            this.ventaDataGridView.DataSource = this.ventaBindingSource;
            this.ventaDataGridView.Location = new System.Drawing.Point(437, 126);
            this.ventaDataGridView.Name = "ventaDataGridView";
            this.ventaDataGridView.Size = new System.Drawing.Size(343, 220);
            this.ventaDataGridView.TabIndex = 47;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(538, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 18);
            this.label2.TabIndex = 48;
            this.label2.Text = "Lista de ventas";
            // 
            // numeroVentaLabel
            // 
            numeroVentaLabel.AutoSize = true;
            numeroVentaLabel.Location = new System.Drawing.Point(119, 126);
            numeroVentaLabel.Name = "numeroVentaLabel";
            numeroVentaLabel.Size = new System.Drawing.Size(186, 13);
            numeroVentaLabel.TabIndex = 48;
            numeroVentaLabel.Text = "Ingrese el numero de vente a eliminar:";
            // 
            // numeroVentaTextBox
            // 
            this.numeroVentaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ventaBindingSource, "numeroVenta", true));
            this.numeroVentaTextBox.Location = new System.Drawing.Point(156, 156);
            this.numeroVentaTextBox.MaxLength = 5;
            this.numeroVentaTextBox.Name = "numeroVentaTextBox";
            this.numeroVentaTextBox.Size = new System.Drawing.Size(126, 20);
            this.numeroVentaTextBox.TabIndex = 49;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(153, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 18);
            this.label1.TabIndex = 50;
            this.label1.Text = "Eliminar Venta";
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(177, 203);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(75, 23);
            this.btnEliminar.TabIndex = 51;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "numeroVenta";
            this.dataGridViewTextBoxColumn1.HeaderText = "Numero venta";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "totalVentaV";
            this.dataGridViewTextBoxColumn2.HeaderText = "Total";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // fechaVentaV
            // 
            this.fechaVentaV.DataPropertyName = "fechaVentaV";
            this.fechaVentaV.HeaderText = "Fecha";
            this.fechaVentaV.Name = "fechaVentaV";
            // 
            // cancelarVenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(892, 469);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.label1);
            this.Controls.Add(numeroVentaLabel);
            this.Controls.Add(this.numeroVentaTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ventaDataGridView);
            this.Controls.Add(this.btnRegresar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "cancelarVenta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cancelar Venta";
            this.Load += new System.EventHandler(this.cancelarVenta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.baseDeDatosPapeleriaSofDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ventaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ventaDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRegresar;
        private BaseDeDatosPapeleriaSofDataSet baseDeDatosPapeleriaSofDataSet;
        private System.Windows.Forms.BindingSource ventaBindingSource;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.VentaTableAdapter ventaTableAdapter;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView ventaDataGridView;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox numeroVentaTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaVentaV;
    }
}