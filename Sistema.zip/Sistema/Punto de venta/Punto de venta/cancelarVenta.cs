﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_venta
{
    public partial class cancelarVenta : Form
    {
        public cancelarVenta()
        {
            InitializeComponent();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            var seleccion = MessageBox.Show("¿Deseas salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (seleccion == DialogResult.Yes)
            {
                this.Hide();
            }
        }

        private void ventaBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.ventaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.baseDeDatosPapeleriaSofDataSet);

        }

        private void cancelarVenta_Load(object sender, EventArgs e)
        {
            numeroVentaTextBox.Text = "";
            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.Venta' Puede moverla o quitarla según sea necesario.
            this.ventaTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.Venta);

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            baseDatos bd = new baseDatos();
            string clave = numeroVentaTextBox.Text;
            bd.eliminarDetallesVenta(clave);
            bd.eliminarVenta(clave);

            MessageBox.Show("Se ha eliminado correctamente la venta " + clave, "Venta eliminada");

            cancelarVenta_Load(sender, e);
        }
    }
}
