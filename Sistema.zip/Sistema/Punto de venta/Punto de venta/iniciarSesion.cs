﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_venta
{
    public partial class iniciarSesion : Form
    {
        public iniciarSesion()
        {
            InitializeComponent();
        }

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(txtBoxID.Text) && !string.IsNullOrEmpty(txtBoxID.Text))
            {
                try
                {
                    baseDatos db = new baseDatos();

                    Boolean res = db.iniciarSesion(txtBoxID.Text, txtBoxContra.Text);
                    
                    if(res)
                    {
                        string nombre = baseDatos.nombreIS;
                        string admin = baseDatos.adminIS;
                        MessageBox.Show("Bienvenido " + nombre);

                        this.Hide();
                        menuPuntoDeVenta ventanaMenuPuntoDeVenta = new menuPuntoDeVenta();
                        ventanaMenuPuntoDeVenta.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Datos incorrectos","Error al iniciar sesion",MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch
                {
                    MessageBox.Show("Imposible conectarse a la base de datos", "Error de conexion", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Complete los campos solicitados", "Datos faltantes", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked)
            {
                txtBoxContra.UseSystemPasswordChar = false;
            }
            else
            {
                txtBoxContra.UseSystemPasswordChar = true;
            }
        }
    }
}
