﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_venta
{
    public partial class realizarVenta : Form
    {
        public Boolean bagre = true;
        public double total = 0;
        public realizarVenta()
        {
            InitializeComponent();
        }

        private void realizarVenta_Load(object sender, EventArgs e)
        {
            if (bagre)
            {
                ventaTuneada();
                bagre = false;
            }

            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.Producto' Puede moverla o quitarla según sea necesario.
            this.productoTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.Producto);
            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.DetallesVenta' Puede moverla o quitarla según sea necesario.
            this.detallesVentaTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.DetallesVenta);
            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.Tienda' Puede moverla o quitarla según sea necesario.
            this.tiendaTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.Tienda);
            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.Venta' Puede moverla o quitarla según sea necesario.
            this.ventaTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.Venta);

            baseDatos bd = new baseDatos();

            dataGridView1.DataSource = bd.tablaDV(txtBoxNumeroVenta.Text);
        }

        public void ventaTuneada()
        {
            baseDatos bd = new baseDatos();

            int cantidadDeVentas = bd.saberCantidadVentas() + 1;
            string cdvString = Convert.ToString(cantidadDeVentas);

            txtBoxNumeroVenta.Text = cdvString;

            string fecha = fechaVentaVDateTimePicker.Value.ToString("yyyy-MM-dd");

            bd.crearVentaVacia(txtBoxNumeroVenta.Text, fecha);
        }

        private void agregarAlCarro_Click(object sender, EventArgs e)
        {
            baseDatos bd = new baseDatos();
            // NUMERO VENTA - CLAVE PRODUCTO - NOMBRE PRODUCTO - CANTIDAD - PRECIO - SUBTOTAL
            string numeroVenta = txtBoxNumeroVenta.Text;
            string claveProducto = nombreProductoComboBox.SelectedValue.ToString();

            string nombreProducto = bd.saberNombreProducto(claveProducto); 

            Double precioProducto = bd.saberPrecioProducto(claveProducto);

            Double cantidad = Double.Parse(txtBoxCantidad.Text);
            Double subtotal = cantidad * precioProducto;

            bd.agregarAlCarrito(numeroVenta, claveProducto, nombreProducto, cantidad, precioProducto, subtotal);
            realizarVenta_Load(sender, e);

            total += subtotal;
            label3.Text = "TOTAL: $" + total;
        }

        private void btnRealizarVenta_Click(object sender, EventArgs e)
        {
            baseDatos bd = new baseDatos();
            double totalVenta = total;
            string numeroVenta = txtBoxNumeroVenta.Text;

            bd.agregarVenta(totalVenta, numeroVenta);
            MessageBox.Show(("El total de la venta es " + total), "Venta Realizada", MessageBoxButtons.OK);
            txtBoxCantidad.Text = "";
            label3.Text = "";

            bagre = true;
            realizarVenta_Load(sender, e);
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            baseDatos bd = new baseDatos();
            var seleccion = MessageBox.Show("¿Deseas salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (seleccion == DialogResult.Yes)
            {
                bd.limpiarCochineroQueHayEnElRadio();
                this.Hide();
            }
        }
    }
}
