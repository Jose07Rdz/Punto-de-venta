﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_venta
{
    public partial class menuPuntoDeVenta : Form
    {
        public menuPuntoDeVenta()
        {
            InitializeComponent();
        }
        private void btnSalir_Click(object sender, EventArgs e)
        {
            var seleccion = MessageBox.Show("¿Deseas salir?","Salir", MessageBoxButtons.YesNo,MessageBoxIcon.Warning);

            if (seleccion == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnAgregarEmpleado_Click(object sender, EventArgs e)
        {
            this.Hide();
            agregarEmpleado ventanaAgregarEmpleado = new agregarEmpleado();
            ventanaAgregarEmpleado.ShowDialog();
            this.Show();
        }

        private void btnEliminarEmpleados_Click(object sender, EventArgs e)
        {
            this.Hide();
            eliminarEmpleado ventanaEliminarEmpleado = new eliminarEmpleado();
            ventanaEliminarEmpleado.ShowDialog();
            this.Show();
        }

        private void btnModificarEmpleado_Click(object sender, EventArgs e)
        {
            this.Hide();
            modificarEmpleado ventanaModificarEmpleado = new modificarEmpleado();
            ventanaModificarEmpleado.ShowDialog();
            this.Show();
        }

        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            this.Hide();
            agregarProducto ventanaAgregarProducto = new agregarProducto();
            ventanaAgregarProducto.ShowDialog();
            this.Show();
        }

        private void btnEliminarProducto_Click(object sender, EventArgs e)
        {
            this.Hide();
            eliminarProducto ventanaEliminarProducto = new eliminarProducto();
            ventanaEliminarProducto.ShowDialog();
            this.Show();
        }

        private void btnModificarProducto_Click(object sender, EventArgs e)
        {
            this.Hide();
            modificarProducto ventanaModificarProducto = new modificarProducto();
            ventanaModificarProducto.ShowDialog();
            this.Show();
        }

        private void btnModificarProveedor_Click(object sender, EventArgs e)
        {
            this.Hide();
            agregarProveedor ventanaAgregarProveedor = new agregarProveedor();
            ventanaAgregarProveedor.ShowDialog();
            this.Show();
        }

        private void btnEliminarProveedor_Click(object sender, EventArgs e)
        {
            this.Hide();
            eliminarProveedor ventanaEP = new eliminarProveedor();
            ventanaEP.ShowDialog();
            this.Show();
        }

        private void btnModProveedor_Click(object sender, EventArgs e)
        {
            this.Hide();
            modificarProveedor ventanaMP = new modificarProveedor();
            ventanaMP.ShowDialog();
            this.Show();
        }

        private void btnProvee_Click(object sender, EventArgs e)
        {
            this.Hide();
            Provee ventanaProvee = new Provee();
            ventanaProvee.ShowDialog();
            this.Show();
        }

        private void btnRealizarVenta_Click(object sender, EventArgs e)
        {
            this.Hide();
            realizarVenta ventanaRV = new realizarVenta();
            ventanaRV.ShowDialog();
            this.Show();

        }

        private void btnCancelarVenta_Click(object sender, EventArgs e)
        {
            this.Hide();
            cancelarVenta ventanaCV = new cancelarVenta();
            ventanaCV.ShowDialog();
            this.Show();
        }
    }
}
