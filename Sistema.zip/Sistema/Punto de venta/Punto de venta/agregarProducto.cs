﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_venta
{
    public partial class agregarProducto : Form
    {
        public agregarProducto()
        {
            InitializeComponent();
        }

        private void productoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.productoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.baseDeDatosPapeleriaSofDataSet);

        }

        private void agregarProducto_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.Producto' Puede moverla o quitarla según sea necesario.
            this.productoTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.Producto);
            claveProductoTextBox.Text = "";
            nombreProductoTextBox.Text = "";
            precioProductoTextBox.Text = "";
            marcaProductoTextBox.Text = "";
            descripcionProductoTextBox.Text = "";
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            var seleccion = MessageBox.Show("¿Deseas salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (seleccion == DialogResult.Yes)
            {
                this.Hide();
            }
        }

        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(claveProductoTextBox.Text) && !string.IsNullOrEmpty(nombreProductoTextBox.Text) && !string.IsNullOrEmpty(precioProductoTextBox.Text) && !string.IsNullOrEmpty(marcaProductoTextBox.Text) && !string.IsNullOrEmpty(descripcionProductoTextBox.Text))
            {
                baseDatos bd = new baseDatos();

                float precioFloat = float.Parse(precioProductoTextBox.Text);

                Boolean res = bd.agregarProducto(claveProductoTextBox.Text, nombreProductoTextBox.Text, precioFloat, marcaProductoTextBox.Text, descripcionProductoTextBox.Text);

                if (res)
                {
                    MessageBox.Show("Se ha registrado correctamente el producto " + nombreProductoTextBox.Text);
                    agregarProducto_Load(sender,e);

                    claveProductoTextBox.Text = "";
                    nombreProductoTextBox.Text = "";
                    precioProductoTextBox.Text = "";
                    marcaProductoTextBox.Text = "";
                    descripcionProductoTextBox.Text = "";
                }
                else
                {
                    MessageBox.Show("No se ha podido agregar el producto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Complete todos los campos", "Datos faltantes", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
