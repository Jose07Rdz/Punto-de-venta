﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_venta
{
    public partial class eliminarProducto : Form
    {
        public eliminarProducto()
        {
            InitializeComponent();
        }

        private void productoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.productoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.baseDeDatosPapeleriaSofDataSet);

        }

        private void eliminarProducto_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.Producto' Puede moverla o quitarla según sea necesario.
            this.productoTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.Producto);
            txtBoxClave.Text = "";
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtBoxClave.Text))
            {
                baseDatos bd = new baseDatos();

                Boolean res = bd.eliminarProducto(txtBoxClave.Text);

                if (res)
                {
                    MessageBox.Show("El producto con clave " + txtBoxClave.Text + " se ha eliminado correctamente", "Producto eliminado", MessageBoxButtons.OK);
                    eliminarProducto_Load(sender, e);
                    
                }
                else
                {
                    MessageBox.Show("No se ha podido eliminar el producto", "Error", MessageBoxButtons.OK);
                }
            }
            else
            {
                MessageBox.Show("Complete los campos solicitados", "Datos faltantes", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            var seleccion = MessageBox.Show("¿Deseas salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (seleccion == DialogResult.Yes)
            {
                this.Hide();
            }
        }
    }
}
