﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_venta
{
    public partial class registrarse : Form
    {
        public registrarse()
        {
            InitializeComponent();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnRegistrarse_Click(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(txtBoxNomPape.Text) && !string.IsNullOrEmpty(txtBoxNomDue.Text) && !string.IsNullOrEmpty(txtBoxRFC.Text) && !string.IsNullOrEmpty(txtBoxDir.Text))
            {
                try
                {
                    baseDatos db = new baseDatos();

                    Boolean registro = db.registrarTienda(txtBoxNomPape.Text,txtBoxNomDue.Text,txtBoxRFC.Text,txtBoxDir.Text);

                    if (registro)
                    {
                        MessageBox.Show("Se ha registrado correctamente la tienda " + txtBoxNomPape.Text);
                        txtBoxDir.Text = "";
                        txtBoxNomDue.Text = "";
                        txtBoxNomPape.Text = "";
                        txtBoxRFC.Text = "";

                        MessageBox.Show("Credenciales Super Usuario\nID Empleado: 000 \nContraseña: ADMIN","Datos usuario",MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        this.Hide();
                        iniciarSesion ventanaInciarSesion = new iniciarSesion();
                        ventanaInciarSesion.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("No se ha podido registrar la tienda");
                    }
                }
                catch
                {
                    MessageBox.Show("Error de conexion");
                }
            }
            else
            {
                MessageBox.Show("Complete los campos solicitados");
            }
        }
    }
}
