﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_venta
{
    public partial class modificarEmpleado : Form
    {
        public modificarEmpleado()
        {
            InitializeComponent();
        }

        private void empleadoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.empleadoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.baseDeDatosPapeleriaSofDataSet);

        }

        private void modificarEmpleado_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.Empleado' Puede moverla o quitarla según sea necesario.
            this.empleadoTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.Empleado);

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            var seleccion = MessageBox.Show("¿Deseas salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (seleccion == DialogResult.Yes)
            {
                this.Hide();
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            baseDatos bd = new baseDatos();

            if (!string.IsNullOrEmpty(claveEmpleadoTextBox.Text) && !string.IsNullOrEmpty(nombreEmpleadoTextBox.Text) && !string.IsNullOrEmpty(telefonoEmpleadoTextBox.Text) && !string.IsNullOrEmpty(empleadoAdminTextBox.Text) && !string.IsNullOrEmpty(passwordEmpleadoTextBox.Text))
            {
                Boolean res = bd.modificarEmpleado(claveEmpleadoTextBox.Text, nombreEmpleadoTextBox.Text, telefonoEmpleadoTextBox.Text, empleadoAdminTextBox.Text, passwordEmpleadoTextBox.Text);
                if (res)
                {
                    MessageBox.Show("Se ha modificado correctamente el usuario " + nombreEmpleadoTextBox.Text);
                    modificarEmpleado_Load(sender, e);
                    claveEmpleadoTextBox.Text = "";
                    nombreEmpleadoTextBox.Text = "";
                    telefonoEmpleadoTextBox.Text = "";
                    empleadoAdminTextBox.Text = "";
                    passwordEmpleadoTextBox.Text = "";
                }
                else
                {
                    MessageBox.Show("No se ha podido modificar el empleado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Complete los campos solicitados", "Datos faltantes", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
