--CREAR BASE DE DATOS
CREATE DATABASE BaseDeDatosPapeleriaSof

USE BaseDeDatosPapeleriaSof

-- CREAR TABLA DE PROVEEDOR
CREATE TABLE Proveedor(
claveProveedor varchar(5) PRIMARY KEY not null,
nombreProveedor varchar(50) not null,
correoProveedor varchar(50),
telefonoProveedor varchar(10),
direccionProveedor varchar(50)
);

-- CREAR TABLA DE PRODUCTOS
CREATE TABLE Producto(
claveProducto varchar(13) PRIMARY KEY not null,
nombreProducto varchar(50) not null,
precioProducto float not null,
marcaProducto varchar(50),
descripcionProducto varchar(50)
);

--CREAR TABLA PROVEE (RELACION DE TABLA DE PRODUCTOS Y PROVEEDOR)
CREATE TABLE Provee(
claveProveedorP varchar(5) not null,
claveProductoP varchar(13) not null,
CONSTRAINT fk_claveProveedor FOREIGN KEY (claveProveedorP) REFERENCES Proveedor(claveProveedor),
CONSTRAINT fk_claveProducto FOREIGN KEY (claveProductoP) REFERENCES Producto(claveProducto)
);

--CREAR TABLA EMPLEADO
CREATE TABLE Empleado(
claveEmpleado varchar(3) PRIMARY KEY not null,
nombreEmpleado varchar(50) not null,
telefonoEmpleado varchar(10),
empleadoAdmin varchar(2) not null,
passwordEmpleado varchar(16) not null
);

INSERT INTO Empleado(claveEmpleado,nombreEmpleado,empleadoAdmin,passwordEmpleado) VALUES ('000', 'ADMIN', 'SI', 'ADMIN');

--CREAR TABLA TIENDA
CREATE TABLE Tienda(
claveTienda varchar(1) PRIMARY KEY not null,
nombreTienda varchar(50) not null,
duenoTienda varchar(50) not null,
RFCTienda varchar(13) not null,
direccionTienda varchar(50) not null
);

INSERT INTO Tienda VALUES ('1' ,'XXX' ,'XXX' ,'XXX' ,'XX');

--CREAR TABLA VENTA
CREATE TABLE Venta(
numeroVenta varchar(7) PRIMARY KEY not null,
claveEmpleadoV varchar(3) not null,
totalVentaV float not null,
fechaVentaV datetime not null,
claveTiendaV varchar(1) not null,
CONSTRAINT fk_claveEmpleadoV FOREIGN KEY (claveEmpleadoV) REFERENCES Empleado(claveEmpleado),
CONSTRAINT fk_claveTiendaV FOREIGN KEY (claveTiendaV) REFERENCES Tienda(claveTienda),
);

--CREAR TABLAS DETALLES VENTA
CREATE TABLE DetallesVenta(
numeroVentaDV varchar(7) not null,
claveProductoDV varchar(13) not null,
nombreProductoDV varchar(50) not null,
cantidadDV float not null,
precio float not null,
subtotalDV float not null,
CONSTRAINT fk_numeroVenta FOREIGN KEY (numeroVentaDV) REFERENCES Venta(numeroVenta),
CONSTRAINT fk_claveProductoDV FOREIGN KEY (claveProductoDV) REFERENCES Producto(claveProducto),
);

