﻿namespace Punto_de_venta
{
    partial class realizarVenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label fechaVentaVLabel;
            System.Windows.Forms.Label nombreTiendaLabel;
            System.Windows.Forms.Label rFCTiendaLabel;
            System.Windows.Forms.Label direccionTiendaLabel;
            System.Windows.Forms.Label cantidadDVLabel;
            System.Windows.Forms.Label nombreProductoLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(realizarVenta));
            this.baseDeDatosPapeleriaSofDataSet = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSet();
            this.ventaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ventaTableAdapter = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.VentaTableAdapter();
            this.tableAdapterManager = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager();
            this.tiendaTableAdapter = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.TiendaTableAdapter();
            this.tiendaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ventaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.txtBoxNumeroVenta = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.fechaVentaVDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.nombreTiendaComboBox = new System.Windows.Forms.ComboBox();
            this.rFCTiendaComboBox = new System.Windows.Forms.ComboBox();
            this.direccionTiendaComboBox = new System.Windows.Forms.ComboBox();
            this.detallesVentaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.detallesVentaTableAdapter = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.DetallesVentaTableAdapter();
            this.detallesVentaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.detallesVentaBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.detallesVentaBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.detallesVentaBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.productoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productoTableAdapter = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.ProductoTableAdapter();
            this.agregarAlCarro = new System.Windows.Forms.Button();
            this.nombreProductoComboBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBoxCantidad = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnRealizarVenta = new System.Windows.Forms.Button();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            fechaVentaVLabel = new System.Windows.Forms.Label();
            nombreTiendaLabel = new System.Windows.Forms.Label();
            rFCTiendaLabel = new System.Windows.Forms.Label();
            direccionTiendaLabel = new System.Windows.Forms.Label();
            cantidadDVLabel = new System.Windows.Forms.Label();
            nombreProductoLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.baseDeDatosPapeleriaSofDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ventaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tiendaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ventaBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.detallesVentaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.detallesVentaBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.detallesVentaBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.detallesVentaBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.detallesVentaBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // fechaVentaVLabel
            // 
            fechaVentaVLabel.AutoSize = true;
            fechaVentaVLabel.Location = new System.Drawing.Point(70, 59);
            fechaVentaVLabel.Name = "fechaVentaVLabel";
            fechaVentaVLabel.Size = new System.Drawing.Size(40, 13);
            fechaVentaVLabel.TabIndex = 2;
            fechaVentaVLabel.Text = "Fecha:";
            // 
            // nombreTiendaLabel
            // 
            nombreTiendaLabel.AutoSize = true;
            nombreTiendaLabel.Location = new System.Drawing.Point(31, 82);
            nombreTiendaLabel.Name = "nombreTiendaLabel";
            nombreTiendaLabel.Size = new System.Drawing.Size(79, 13);
            nombreTiendaLabel.TabIndex = 4;
            nombreTiendaLabel.Text = "Nombre tienda:";
            // 
            // rFCTiendaLabel
            // 
            rFCTiendaLabel.AutoSize = true;
            rFCTiendaLabel.Location = new System.Drawing.Point(79, 108);
            rFCTiendaLabel.Name = "rFCTiendaLabel";
            rFCTiendaLabel.Size = new System.Drawing.Size(31, 13);
            rFCTiendaLabel.TabIndex = 6;
            rFCTiendaLabel.Text = "RFC:";
            // 
            // direccionTiendaLabel
            // 
            direccionTiendaLabel.AutoSize = true;
            direccionTiendaLabel.Location = new System.Drawing.Point(55, 135);
            direccionTiendaLabel.Name = "direccionTiendaLabel";
            direccionTiendaLabel.Size = new System.Drawing.Size(55, 13);
            direccionTiendaLabel.TabIndex = 8;
            direccionTiendaLabel.Text = "Direccion:";
            // 
            // cantidadDVLabel
            // 
            cantidadDVLabel.AutoSize = true;
            cantidadDVLabel.Location = new System.Drawing.Point(58, 256);
            cantidadDVLabel.Name = "cantidadDVLabel";
            cantidadDVLabel.Size = new System.Drawing.Size(52, 13);
            cantidadDVLabel.TabIndex = 13;
            cantidadDVLabel.Text = "Cantidad:";
            // 
            // nombreProductoLabel
            // 
            nombreProductoLabel.AutoSize = true;
            nombreProductoLabel.Location = new System.Drawing.Point(57, 225);
            nombreProductoLabel.Name = "nombreProductoLabel";
            nombreProductoLabel.Size = new System.Drawing.Size(53, 13);
            nombreProductoLabel.TabIndex = 16;
            nombreProductoLabel.Text = "Producto:";
            // 
            // baseDeDatosPapeleriaSofDataSet
            // 
            this.baseDeDatosPapeleriaSofDataSet.DataSetName = "BaseDeDatosPapeleriaSofDataSet";
            this.baseDeDatosPapeleriaSofDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ventaBindingSource
            // 
            this.ventaBindingSource.DataMember = "Venta";
            this.ventaBindingSource.DataSource = this.baseDeDatosPapeleriaSofDataSet;
            // 
            // ventaTableAdapter
            // 
            this.ventaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DetallesVentaTableAdapter = null;
            this.tableAdapterManager.EmpleadoTableAdapter = null;
            this.tableAdapterManager.ProductoTableAdapter = null;
            this.tableAdapterManager.ProveedorTableAdapter = null;
            this.tableAdapterManager.ProveeTableAdapter = null;
            this.tableAdapterManager.TiendaTableAdapter = this.tiendaTableAdapter;
            this.tableAdapterManager.UpdateOrder = Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VentaTableAdapter = this.ventaTableAdapter;
            // 
            // tiendaTableAdapter
            // 
            this.tiendaTableAdapter.ClearBeforeFill = true;
            // 
            // tiendaBindingSource
            // 
            this.tiendaBindingSource.DataMember = "Tienda";
            this.tiendaBindingSource.DataSource = this.baseDeDatosPapeleriaSofDataSet;
            // 
            // ventaBindingSource1
            // 
            this.ventaBindingSource1.DataMember = "Venta";
            this.ventaBindingSource1.DataSource = this.baseDeDatosPapeleriaSofDataSet;
            // 
            // txtBoxNumeroVenta
            // 
            this.txtBoxNumeroVenta.Enabled = false;
            this.txtBoxNumeroVenta.Location = new System.Drawing.Point(116, 27);
            this.txtBoxNumeroVenta.Name = "txtBoxNumeroVenta";
            this.txtBoxNumeroVenta.Size = new System.Drawing.Size(121, 20);
            this.txtBoxNumeroVenta.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Numero de venta:";
            // 
            // fechaVentaVDateTimePicker
            // 
            this.fechaVentaVDateTimePicker.CustomFormat = "";
            this.fechaVentaVDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.ventaBindingSource, "fechaVentaV", true));
            this.fechaVentaVDateTimePicker.Location = new System.Drawing.Point(116, 53);
            this.fechaVentaVDateTimePicker.Name = "fechaVentaVDateTimePicker";
            this.fechaVentaVDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.fechaVentaVDateTimePicker.TabIndex = 3;
            // 
            // nombreTiendaComboBox
            // 
            this.nombreTiendaComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tiendaBindingSource, "nombreTienda", true));
            this.nombreTiendaComboBox.Enabled = false;
            this.nombreTiendaComboBox.FormattingEnabled = true;
            this.nombreTiendaComboBox.Location = new System.Drawing.Point(116, 79);
            this.nombreTiendaComboBox.Name = "nombreTiendaComboBox";
            this.nombreTiendaComboBox.Size = new System.Drawing.Size(121, 21);
            this.nombreTiendaComboBox.TabIndex = 5;
            // 
            // rFCTiendaComboBox
            // 
            this.rFCTiendaComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tiendaBindingSource, "RFCTienda", true));
            this.rFCTiendaComboBox.Enabled = false;
            this.rFCTiendaComboBox.FormattingEnabled = true;
            this.rFCTiendaComboBox.Location = new System.Drawing.Point(116, 105);
            this.rFCTiendaComboBox.Name = "rFCTiendaComboBox";
            this.rFCTiendaComboBox.Size = new System.Drawing.Size(121, 21);
            this.rFCTiendaComboBox.TabIndex = 7;
            // 
            // direccionTiendaComboBox
            // 
            this.direccionTiendaComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tiendaBindingSource, "direccionTienda", true));
            this.direccionTiendaComboBox.Enabled = false;
            this.direccionTiendaComboBox.FormattingEnabled = true;
            this.direccionTiendaComboBox.Location = new System.Drawing.Point(116, 132);
            this.direccionTiendaComboBox.Name = "direccionTiendaComboBox";
            this.direccionTiendaComboBox.Size = new System.Drawing.Size(121, 21);
            this.direccionTiendaComboBox.TabIndex = 9;
            // 
            // detallesVentaBindingSource
            // 
            this.detallesVentaBindingSource.DataMember = "fk_numeroVenta";
            this.detallesVentaBindingSource.DataSource = this.ventaBindingSource;
            // 
            // detallesVentaTableAdapter
            // 
            this.detallesVentaTableAdapter.ClearBeforeFill = true;
            // 
            // detallesVentaBindingSource1
            // 
            this.detallesVentaBindingSource1.DataMember = "fk_numeroVenta";
            this.detallesVentaBindingSource1.DataSource = this.ventaBindingSource;
            // 
            // detallesVentaBindingSource2
            // 
            this.detallesVentaBindingSource2.DataMember = "fk_numeroVenta";
            this.detallesVentaBindingSource2.DataSource = this.ventaBindingSource;
            // 
            // detallesVentaBindingSource3
            // 
            this.detallesVentaBindingSource3.DataMember = "DetallesVenta";
            this.detallesVentaBindingSource3.DataSource = this.baseDeDatosPapeleriaSofDataSet;
            // 
            // detallesVentaBindingSource4
            // 
            this.detallesVentaBindingSource4.DataMember = "DetallesVenta";
            this.detallesVentaBindingSource4.DataSource = this.baseDeDatosPapeleriaSofDataSet;
            // 
            // productoBindingSource
            // 
            this.productoBindingSource.DataMember = "Producto";
            this.productoBindingSource.DataSource = this.baseDeDatosPapeleriaSofDataSet;
            // 
            // productoTableAdapter
            // 
            this.productoTableAdapter.ClearBeforeFill = true;
            // 
            // agregarAlCarro
            // 
            this.agregarAlCarro.Location = new System.Drawing.Point(82, 286);
            this.agregarAlCarro.Name = "agregarAlCarro";
            this.agregarAlCarro.Size = new System.Drawing.Size(96, 23);
            this.agregarAlCarro.TabIndex = 15;
            this.agregarAlCarro.Text = "Agregar al carrito";
            this.agregarAlCarro.UseVisualStyleBackColor = true;
            this.agregarAlCarro.Click += new System.EventHandler(this.agregarAlCarro_Click);
            // 
            // nombreProductoComboBox
            // 
            this.nombreProductoComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productoBindingSource, "nombreProducto", true));
            this.nombreProductoComboBox.DataSource = this.productoBindingSource;
            this.nombreProductoComboBox.DisplayMember = "nombreProducto";
            this.nombreProductoComboBox.FormattingEnabled = true;
            this.nombreProductoComboBox.Location = new System.Drawing.Point(116, 222);
            this.nombreProductoComboBox.Name = "nombreProductoComboBox";
            this.nombreProductoComboBox.Size = new System.Drawing.Size(121, 21);
            this.nombreProductoComboBox.TabIndex = 17;
            this.nombreProductoComboBox.ValueMember = "claveProducto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(543, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 18);
            this.label2.TabIndex = 29;
            this.label2.Text = "Carrito de compra";
            // 
            // txtBoxCantidad
            // 
            this.txtBoxCantidad.Location = new System.Drawing.Point(116, 253);
            this.txtBoxCantidad.Name = "txtBoxCantidad";
            this.txtBoxCantidad.Size = new System.Drawing.Size(121, 20);
            this.txtBoxCantidad.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(776, 291);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 16);
            this.label3.TabIndex = 32;
            // 
            // btnRealizarVenta
            // 
            this.btnRealizarVenta.Location = new System.Drawing.Point(779, 329);
            this.btnRealizarVenta.Name = "btnRealizarVenta";
            this.btnRealizarVenta.Size = new System.Drawing.Size(99, 23);
            this.btnRealizarVenta.TabIndex = 33;
            this.btnRealizarVenta.Text = "Realizar venta";
            this.btnRealizarVenta.UseVisualStyleBackColor = true;
            this.btnRealizarVenta.Click += new System.EventHandler(this.btnRealizarVenta_Click);
            // 
            // btnRegresar
            // 
            this.btnRegresar.Location = new System.Drawing.Point(831, 426);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(75, 23);
            this.btnRegresar.TabIndex = 45;
            this.btnRegresar.Text = "Regresar";
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(380, 53);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(526, 220);
            this.dataGridView1.TabIndex = 46;
            // 
            // realizarVenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(926, 469);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.btnRealizarVenta);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtBoxCantidad);
            this.Controls.Add(this.label2);
            this.Controls.Add(nombreProductoLabel);
            this.Controls.Add(this.nombreProductoComboBox);
            this.Controls.Add(this.agregarAlCarro);
            this.Controls.Add(cantidadDVLabel);
            this.Controls.Add(direccionTiendaLabel);
            this.Controls.Add(this.direccionTiendaComboBox);
            this.Controls.Add(rFCTiendaLabel);
            this.Controls.Add(this.rFCTiendaComboBox);
            this.Controls.Add(nombreTiendaLabel);
            this.Controls.Add(this.nombreTiendaComboBox);
            this.Controls.Add(fechaVentaVLabel);
            this.Controls.Add(this.fechaVentaVDateTimePicker);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtBoxNumeroVenta);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "realizarVenta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Realizar Venta";
            this.Load += new System.EventHandler(this.realizarVenta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.baseDeDatosPapeleriaSofDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ventaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tiendaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ventaBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.detallesVentaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.detallesVentaBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.detallesVentaBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.detallesVentaBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.detallesVentaBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private BaseDeDatosPapeleriaSofDataSet baseDeDatosPapeleriaSofDataSet;
        private System.Windows.Forms.BindingSource ventaBindingSource;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.VentaTableAdapter ventaTableAdapter;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.TiendaTableAdapter tiendaTableAdapter;
        private System.Windows.Forms.BindingSource tiendaBindingSource;
        private System.Windows.Forms.BindingSource ventaBindingSource1;
        private System.Windows.Forms.TextBox txtBoxNumeroVenta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker fechaVentaVDateTimePicker;
        private System.Windows.Forms.ComboBox nombreTiendaComboBox;
        private System.Windows.Forms.ComboBox rFCTiendaComboBox;
        private System.Windows.Forms.ComboBox direccionTiendaComboBox;
        private System.Windows.Forms.BindingSource detallesVentaBindingSource;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.DetallesVentaTableAdapter detallesVentaTableAdapter;
        private System.Windows.Forms.BindingSource detallesVentaBindingSource1;
        private System.Windows.Forms.BindingSource detallesVentaBindingSource2;
        private System.Windows.Forms.BindingSource detallesVentaBindingSource3;
        private System.Windows.Forms.BindingSource detallesVentaBindingSource4;
        private System.Windows.Forms.BindingSource productoBindingSource;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.ProductoTableAdapter productoTableAdapter;
        private System.Windows.Forms.Button agregarAlCarro;
        private System.Windows.Forms.ComboBox nombreProductoComboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBoxCantidad;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnRealizarVenta;
        private System.Windows.Forms.Button btnRegresar;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}