﻿namespace Punto_de_venta
{
    partial class modificarProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label claveProductoLabel;
            System.Windows.Forms.Label nombreProductoLabel;
            System.Windows.Forms.Label precioProductoLabel;
            System.Windows.Forms.Label marcaProductoLabel;
            System.Windows.Forms.Label descripcionProductoLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(modificarProducto));
            this.baseDeDatosPapeleriaSofDataSet = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSet();
            this.productoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productoTableAdapter = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.ProductoTableAdapter();
            this.tableAdapterManager = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager();
            this.productoDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.claveProductoTextBox = new System.Windows.Forms.TextBox();
            this.nombreProductoTextBox = new System.Windows.Forms.TextBox();
            this.precioProductoTextBox = new System.Windows.Forms.TextBox();
            this.marcaProductoTextBox = new System.Windows.Forms.TextBox();
            this.descripcionProductoTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnModificar = new System.Windows.Forms.Button();
            this.btnRegresar = new System.Windows.Forms.Button();
            claveProductoLabel = new System.Windows.Forms.Label();
            nombreProductoLabel = new System.Windows.Forms.Label();
            precioProductoLabel = new System.Windows.Forms.Label();
            marcaProductoLabel = new System.Windows.Forms.Label();
            descripcionProductoLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.baseDeDatosPapeleriaSofDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productoDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // baseDeDatosPapeleriaSofDataSet
            // 
            this.baseDeDatosPapeleriaSofDataSet.DataSetName = "BaseDeDatosPapeleriaSofDataSet";
            this.baseDeDatosPapeleriaSofDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productoBindingSource
            // 
            this.productoBindingSource.DataMember = "Producto";
            this.productoBindingSource.DataSource = this.baseDeDatosPapeleriaSofDataSet;
            // 
            // productoTableAdapter
            // 
            this.productoTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DetallesVentaTableAdapter = null;
            this.tableAdapterManager.EmpleadoTableAdapter = null;
            this.tableAdapterManager.ProductoTableAdapter = this.productoTableAdapter;
            this.tableAdapterManager.ProveedorTableAdapter = null;
            this.tableAdapterManager.ProveeTableAdapter = null;
            this.tableAdapterManager.TiendaTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VentaTableAdapter = null;
            // 
            // productoDataGridView
            // 
            this.productoDataGridView.AutoGenerateColumns = false;
            this.productoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.productoDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.productoDataGridView.DataSource = this.productoBindingSource;
            this.productoDataGridView.Location = new System.Drawing.Point(310, 86);
            this.productoDataGridView.Name = "productoDataGridView";
            this.productoDataGridView.Size = new System.Drawing.Size(544, 254);
            this.productoDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "claveProducto";
            this.dataGridViewTextBoxColumn1.HeaderText = "claveProducto";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "nombreProducto";
            this.dataGridViewTextBoxColumn2.HeaderText = "nombreProducto";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "precioProducto";
            this.dataGridViewTextBoxColumn3.HeaderText = "precioProducto";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "marcaProducto";
            this.dataGridViewTextBoxColumn4.HeaderText = "marcaProducto";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "descripcionProducto";
            this.dataGridViewTextBoxColumn5.HeaderText = "descripcionProducto";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // claveProductoLabel
            // 
            claveProductoLabel.AutoSize = true;
            claveProductoLabel.Location = new System.Drawing.Point(102, 89);
            claveProductoLabel.Name = "claveProductoLabel";
            claveProductoLabel.Size = new System.Drawing.Size(41, 13);
            claveProductoLabel.TabIndex = 1;
            claveProductoLabel.Text = "*Clave:";
            // 
            // claveProductoTextBox
            // 
            this.claveProductoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productoBindingSource, "claveProducto", true));
            this.claveProductoTextBox.Location = new System.Drawing.Point(149, 86);
            this.claveProductoTextBox.Name = "claveProductoTextBox";
            this.claveProductoTextBox.Size = new System.Drawing.Size(126, 20);
            this.claveProductoTextBox.TabIndex = 2;
            // 
            // nombreProductoLabel
            // 
            nombreProductoLabel.AutoSize = true;
            nombreProductoLabel.Location = new System.Drawing.Point(96, 161);
            nombreProductoLabel.Name = "nombreProductoLabel";
            nombreProductoLabel.Size = new System.Drawing.Size(47, 13);
            nombreProductoLabel.TabIndex = 3;
            nombreProductoLabel.Text = "Nombre:";
            // 
            // nombreProductoTextBox
            // 
            this.nombreProductoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productoBindingSource, "nombreProducto", true));
            this.nombreProductoTextBox.Location = new System.Drawing.Point(149, 158);
            this.nombreProductoTextBox.Name = "nombreProductoTextBox";
            this.nombreProductoTextBox.Size = new System.Drawing.Size(126, 20);
            this.nombreProductoTextBox.TabIndex = 4;
            // 
            // precioProductoLabel
            // 
            precioProductoLabel.AutoSize = true;
            precioProductoLabel.Location = new System.Drawing.Point(103, 187);
            precioProductoLabel.Name = "precioProductoLabel";
            precioProductoLabel.Size = new System.Drawing.Size(40, 13);
            precioProductoLabel.TabIndex = 5;
            precioProductoLabel.Text = "Precio:";
            // 
            // precioProductoTextBox
            // 
            this.precioProductoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productoBindingSource, "precioProducto", true));
            this.precioProductoTextBox.Location = new System.Drawing.Point(149, 184);
            this.precioProductoTextBox.Name = "precioProductoTextBox";
            this.precioProductoTextBox.Size = new System.Drawing.Size(126, 20);
            this.precioProductoTextBox.TabIndex = 6;
            // 
            // marcaProductoLabel
            // 
            marcaProductoLabel.AutoSize = true;
            marcaProductoLabel.Location = new System.Drawing.Point(103, 213);
            marcaProductoLabel.Name = "marcaProductoLabel";
            marcaProductoLabel.Size = new System.Drawing.Size(40, 13);
            marcaProductoLabel.TabIndex = 7;
            marcaProductoLabel.Text = "Marca:";
            // 
            // marcaProductoTextBox
            // 
            this.marcaProductoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productoBindingSource, "marcaProducto", true));
            this.marcaProductoTextBox.Location = new System.Drawing.Point(149, 210);
            this.marcaProductoTextBox.Name = "marcaProductoTextBox";
            this.marcaProductoTextBox.Size = new System.Drawing.Size(126, 20);
            this.marcaProductoTextBox.TabIndex = 8;
            // 
            // descripcionProductoLabel
            // 
            descripcionProductoLabel.AutoSize = true;
            descripcionProductoLabel.Location = new System.Drawing.Point(77, 239);
            descripcionProductoLabel.Name = "descripcionProductoLabel";
            descripcionProductoLabel.Size = new System.Drawing.Size(66, 13);
            descripcionProductoLabel.TabIndex = 9;
            descripcionProductoLabel.Text = "Descripcion:";
            // 
            // descripcionProductoTextBox
            // 
            this.descripcionProductoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productoBindingSource, "descripcionProducto", true));
            this.descripcionProductoTextBox.Location = new System.Drawing.Point(149, 236);
            this.descripcionProductoTextBox.Name = "descripcionProductoTextBox";
            this.descripcionProductoTextBox.Size = new System.Drawing.Size(126, 20);
            this.descripcionProductoTextBox.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(503, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 18);
            this.label1.TabIndex = 27;
            this.label1.Text = "Lista de productos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(104, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 18);
            this.label2.TabIndex = 28;
            this.label2.Text = "Modificar Producto";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(106, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 13);
            this.label3.TabIndex = 41;
            this.label3.Text = "* La clave no se puede cambiar";
            // 
            // btnModificar
            // 
            this.btnModificar.Location = new System.Drawing.Point(149, 317);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(75, 23);
            this.btnModificar.TabIndex = 42;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = true;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // btnRegresar
            // 
            this.btnRegresar.Location = new System.Drawing.Point(797, 426);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(75, 23);
            this.btnRegresar.TabIndex = 43;
            this.btnRegresar.Text = "Regresar";
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // modificarProducto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 461);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.btnModificar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(claveProductoLabel);
            this.Controls.Add(this.claveProductoTextBox);
            this.Controls.Add(nombreProductoLabel);
            this.Controls.Add(this.nombreProductoTextBox);
            this.Controls.Add(precioProductoLabel);
            this.Controls.Add(this.precioProductoTextBox);
            this.Controls.Add(marcaProductoLabel);
            this.Controls.Add(this.marcaProductoTextBox);
            this.Controls.Add(descripcionProductoLabel);
            this.Controls.Add(this.descripcionProductoTextBox);
            this.Controls.Add(this.productoDataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "modificarProducto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Modificar Producto";
            this.Load += new System.EventHandler(this.modificarProducto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.baseDeDatosPapeleriaSofDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productoDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BaseDeDatosPapeleriaSofDataSet baseDeDatosPapeleriaSofDataSet;
        private System.Windows.Forms.BindingSource productoBindingSource;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.ProductoTableAdapter productoTableAdapter;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView productoDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.TextBox claveProductoTextBox;
        private System.Windows.Forms.TextBox nombreProductoTextBox;
        private System.Windows.Forms.TextBox precioProductoTextBox;
        private System.Windows.Forms.TextBox marcaProductoTextBox;
        private System.Windows.Forms.TextBox descripcionProductoTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btnRegresar;
    }
}