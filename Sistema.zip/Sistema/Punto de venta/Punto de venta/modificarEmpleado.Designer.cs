﻿namespace Punto_de_venta
{
    partial class modificarEmpleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label claveEmpleadoLabel;
            System.Windows.Forms.Label nombreEmpleadoLabel;
            System.Windows.Forms.Label telefonoEmpleadoLabel;
            System.Windows.Forms.Label empleadoAdminLabel;
            System.Windows.Forms.Label passwordEmpleadoLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(modificarEmpleado));
            this.baseDeDatosPapeleriaSofDataSet = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSet();
            this.empleadoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.empleadoTableAdapter = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.EmpleadoTableAdapter();
            this.tableAdapterManager = new Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager();
            this.empleadoDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnModificar = new System.Windows.Forms.Button();
            this.claveEmpleadoTextBox = new System.Windows.Forms.TextBox();
            this.nombreEmpleadoTextBox = new System.Windows.Forms.TextBox();
            this.telefonoEmpleadoTextBox = new System.Windows.Forms.TextBox();
            this.empleadoAdminTextBox = new System.Windows.Forms.TextBox();
            this.passwordEmpleadoTextBox = new System.Windows.Forms.TextBox();
            this.btnRegresar = new System.Windows.Forms.Button();
            claveEmpleadoLabel = new System.Windows.Forms.Label();
            nombreEmpleadoLabel = new System.Windows.Forms.Label();
            telefonoEmpleadoLabel = new System.Windows.Forms.Label();
            empleadoAdminLabel = new System.Windows.Forms.Label();
            passwordEmpleadoLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.baseDeDatosPapeleriaSofDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.empleadoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.empleadoDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // claveEmpleadoLabel
            // 
            claveEmpleadoLabel.AutoSize = true;
            claveEmpleadoLabel.Location = new System.Drawing.Point(92, 65);
            claveEmpleadoLabel.Name = "claveEmpleadoLabel";
            claveEmpleadoLabel.Size = new System.Drawing.Size(41, 13);
            claveEmpleadoLabel.TabIndex = 28;
            claveEmpleadoLabel.Text = "*Clave:";
            // 
            // nombreEmpleadoLabel
            // 
            nombreEmpleadoLabel.AutoSize = true;
            nombreEmpleadoLabel.Location = new System.Drawing.Point(86, 134);
            nombreEmpleadoLabel.Name = "nombreEmpleadoLabel";
            nombreEmpleadoLabel.Size = new System.Drawing.Size(47, 13);
            nombreEmpleadoLabel.TabIndex = 30;
            nombreEmpleadoLabel.Text = "Nombre:";
            // 
            // telefonoEmpleadoLabel
            // 
            telefonoEmpleadoLabel.AutoSize = true;
            telefonoEmpleadoLabel.Location = new System.Drawing.Point(81, 160);
            telefonoEmpleadoLabel.Name = "telefonoEmpleadoLabel";
            telefonoEmpleadoLabel.Size = new System.Drawing.Size(52, 13);
            telefonoEmpleadoLabel.TabIndex = 32;
            telefonoEmpleadoLabel.Text = "Telefono:";
            // 
            // empleadoAdminLabel
            // 
            empleadoAdminLabel.AutoSize = true;
            empleadoAdminLabel.Location = new System.Drawing.Point(59, 186);
            empleadoAdminLabel.Name = "empleadoAdminLabel";
            empleadoAdminLabel.Size = new System.Drawing.Size(74, 13);
            empleadoAdminLabel.TabIndex = 34;
            empleadoAdminLabel.Text = "**¿Es Admin?:";
            // 
            // passwordEmpleadoLabel
            // 
            passwordEmpleadoLabel.AutoSize = true;
            passwordEmpleadoLabel.Location = new System.Drawing.Point(69, 212);
            passwordEmpleadoLabel.Name = "passwordEmpleadoLabel";
            passwordEmpleadoLabel.Size = new System.Drawing.Size(64, 13);
            passwordEmpleadoLabel.TabIndex = 36;
            passwordEmpleadoLabel.Text = "Contraseña:";
            // 
            // baseDeDatosPapeleriaSofDataSet
            // 
            this.baseDeDatosPapeleriaSofDataSet.DataSetName = "BaseDeDatosPapeleriaSofDataSet";
            this.baseDeDatosPapeleriaSofDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // empleadoBindingSource
            // 
            this.empleadoBindingSource.DataMember = "Empleado";
            this.empleadoBindingSource.DataSource = this.baseDeDatosPapeleriaSofDataSet;
            // 
            // empleadoTableAdapter
            // 
            this.empleadoTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DetallesVentaTableAdapter = null;
            this.tableAdapterManager.EmpleadoTableAdapter = this.empleadoTableAdapter;
            this.tableAdapterManager.ProductoTableAdapter = null;
            this.tableAdapterManager.ProveedorTableAdapter = null;
            this.tableAdapterManager.ProveeTableAdapter = null;
            this.tableAdapterManager.TiendaTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Punto_de_venta.BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VentaTableAdapter = null;
            // 
            // empleadoDataGridView
            // 
            this.empleadoDataGridView.AutoGenerateColumns = false;
            this.empleadoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.empleadoDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.empleadoDataGridView.DataSource = this.empleadoBindingSource;
            this.empleadoDataGridView.Location = new System.Drawing.Point(329, 62);
            this.empleadoDataGridView.Name = "empleadoDataGridView";
            this.empleadoDataGridView.Size = new System.Drawing.Size(543, 307);
            this.empleadoDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "claveEmpleado";
            this.dataGridViewTextBoxColumn1.HeaderText = "claveEmpleado";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "nombreEmpleado";
            this.dataGridViewTextBoxColumn2.HeaderText = "nombreEmpleado";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "telefonoEmpleado";
            this.dataGridViewTextBoxColumn3.HeaderText = "telefonoEmpleado";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "empleadoAdmin";
            this.dataGridViewTextBoxColumn4.HeaderText = "empleadoAdmin";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "passwordEmpleado";
            this.dataGridViewTextBoxColumn5.HeaderText = "passwordEmpleado";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(492, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 18);
            this.label1.TabIndex = 26;
            this.label1.Text = "Lista de empleados";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(92, 310);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 13);
            this.label4.TabIndex = 41;
            this.label4.Text = "** Posibles respuestas: SI/NO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(96, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 13);
            this.label3.TabIndex = 40;
            this.label3.Text = "* La clave no se puede cambiar";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(96, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(164, 18);
            this.label5.TabIndex = 39;
            this.label5.Text = "Modificar Empleado";
            // 
            // btnModificar
            // 
            this.btnModificar.Location = new System.Drawing.Point(123, 246);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(75, 23);
            this.btnModificar.TabIndex = 38;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = true;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // claveEmpleadoTextBox
            // 
            this.claveEmpleadoTextBox.Location = new System.Drawing.Point(139, 62);
            this.claveEmpleadoTextBox.MaxLength = 3;
            this.claveEmpleadoTextBox.Name = "claveEmpleadoTextBox";
            this.claveEmpleadoTextBox.Size = new System.Drawing.Size(138, 20);
            this.claveEmpleadoTextBox.TabIndex = 29;
            // 
            // nombreEmpleadoTextBox
            // 
            this.nombreEmpleadoTextBox.Location = new System.Drawing.Point(139, 131);
            this.nombreEmpleadoTextBox.MaxLength = 50;
            this.nombreEmpleadoTextBox.Name = "nombreEmpleadoTextBox";
            this.nombreEmpleadoTextBox.Size = new System.Drawing.Size(138, 20);
            this.nombreEmpleadoTextBox.TabIndex = 31;
            // 
            // telefonoEmpleadoTextBox
            // 
            this.telefonoEmpleadoTextBox.Location = new System.Drawing.Point(139, 157);
            this.telefonoEmpleadoTextBox.MaxLength = 10;
            this.telefonoEmpleadoTextBox.Name = "telefonoEmpleadoTextBox";
            this.telefonoEmpleadoTextBox.Size = new System.Drawing.Size(138, 20);
            this.telefonoEmpleadoTextBox.TabIndex = 33;
            // 
            // empleadoAdminTextBox
            // 
            this.empleadoAdminTextBox.Location = new System.Drawing.Point(139, 183);
            this.empleadoAdminTextBox.MaxLength = 2;
            this.empleadoAdminTextBox.Name = "empleadoAdminTextBox";
            this.empleadoAdminTextBox.Size = new System.Drawing.Size(138, 20);
            this.empleadoAdminTextBox.TabIndex = 35;
            // 
            // passwordEmpleadoTextBox
            // 
            this.passwordEmpleadoTextBox.Location = new System.Drawing.Point(139, 209);
            this.passwordEmpleadoTextBox.MaxLength = 16;
            this.passwordEmpleadoTextBox.Name = "passwordEmpleadoTextBox";
            this.passwordEmpleadoTextBox.Size = new System.Drawing.Size(138, 20);
            this.passwordEmpleadoTextBox.TabIndex = 37;
            // 
            // btnRegresar
            // 
            this.btnRegresar.Location = new System.Drawing.Point(797, 426);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(75, 23);
            this.btnRegresar.TabIndex = 42;
            this.btnRegresar.Text = "Regresar";
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // modificarEmpleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 461);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnModificar);
            this.Controls.Add(claveEmpleadoLabel);
            this.Controls.Add(this.claveEmpleadoTextBox);
            this.Controls.Add(nombreEmpleadoLabel);
            this.Controls.Add(this.nombreEmpleadoTextBox);
            this.Controls.Add(telefonoEmpleadoLabel);
            this.Controls.Add(this.telefonoEmpleadoTextBox);
            this.Controls.Add(empleadoAdminLabel);
            this.Controls.Add(this.empleadoAdminTextBox);
            this.Controls.Add(passwordEmpleadoLabel);
            this.Controls.Add(this.passwordEmpleadoTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.empleadoDataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "modificarEmpleado";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Modificar Empleado";
            this.Load += new System.EventHandler(this.modificarEmpleado_Load);
            ((System.ComponentModel.ISupportInitialize)(this.baseDeDatosPapeleriaSofDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.empleadoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.empleadoDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BaseDeDatosPapeleriaSofDataSet baseDeDatosPapeleriaSofDataSet;
        private System.Windows.Forms.BindingSource empleadoBindingSource;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.EmpleadoTableAdapter empleadoTableAdapter;
        private BaseDeDatosPapeleriaSofDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView empleadoDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.TextBox claveEmpleadoTextBox;
        private System.Windows.Forms.TextBox nombreEmpleadoTextBox;
        private System.Windows.Forms.TextBox telefonoEmpleadoTextBox;
        private System.Windows.Forms.TextBox empleadoAdminTextBox;
        private System.Windows.Forms.TextBox passwordEmpleadoTextBox;
        private System.Windows.Forms.Button btnRegresar;
    }
}