﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_venta
{
    public partial class agregarProveedor : Form
    {
        public agregarProveedor()
        {
            InitializeComponent();
        }

        private void proveedorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.proveedorBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.baseDeDatosPapeleriaSofDataSet);

        }

        private void agregarProveedor_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'baseDeDatosPapeleriaSofDataSet.Proveedor' Puede moverla o quitarla según sea necesario.
            this.proveedorTableAdapter.Fill(this.baseDeDatosPapeleriaSofDataSet.Proveedor);
            claveProveedorTextBox.Text = "";
            nombreProveedorTextBox.Text = "";
            telefonoProveedorTextBox.Text = "";
            correoProveedorTextBox.Text = "";
            direccionProveedorTextBox.Text = "";
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            var seleccion = MessageBox.Show("¿Deseas salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (seleccion == DialogResult.Yes)
            {
                this.Hide();
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(claveProveedorTextBox.Text) && !string.IsNullOrEmpty(nombreProveedorTextBox.Text) && !string.IsNullOrEmpty(telefonoProveedorTextBox.Text) && !string.IsNullOrEmpty(correoProveedorTextBox.Text) && !string.IsNullOrEmpty(direccionProveedorTextBox.Text))
            {
                baseDatos bd = new baseDatos();
                Boolean res = bd.agregarProveedor(claveProveedorTextBox.Text, nombreProveedorTextBox.Text, correoProveedorTextBox.Text, telefonoProveedorTextBox.Text,  direccionProveedorTextBox.Text);
                if (res)
                {
                    MessageBox.Show("Se ha registrado correctamente el proveedor " + nombreProveedorTextBox.Text);
                    agregarProveedor_Load(sender, e);
                }
                else
                {
                    MessageBox.Show("No se ha podido agregar el proveedor", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else
            {
                MessageBox.Show("Complete los campos solicitados", "Datos faltantes", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
