﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_venta
{
    public partial class menuPrincipal : Form
    {
        public menuPrincipal()
        {
            InitializeComponent();
        }

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            this.Hide();
            iniciarSesion ventanaIniciarSesion = new iniciarSesion();
            ventanaIniciarSesion.ShowDialog();
            this.Show();
        }

        private void btnRegistrarTienda_Click(object sender, EventArgs e)
        {
            this.Hide();
            registrarse ventanaRegistrarse = new registrarse();
            ventanaRegistrarse.ShowDialog();
            this.Show();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            var respuesta = MessageBox.Show("¿Seguro deseas salir?", "Cerrar", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);

            if(respuesta == DialogResult.Yes)
            {
                this.Close();
            }

        }

        private void menuPrincipal_Load(object sender, EventArgs e)
        {

        }
    }
}
